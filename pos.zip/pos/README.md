# Java Point Of Sale (POS)

### Note: A better version of this repository is in another repository where you will get fully functional pos except the finance module. https://github.com/inforkgodara/store-pos

## Screenshots

### Login - POS
![login - POS](https://raw.github.com/inforkgodara/java-point-of-sale/master/screenshots/java-pos-login.png?raw=true "login")

### Sales Invoice - POS
![Sales Invoice - POS](https://raw.github.com/inforkgodara/java-point-of-sale/master/screenshots/java-pos-sales-invoice.png?raw=true "login")

### Sales Invoice Data - POS
![Sales Invoice Data - POS](https://raw.github.com/inforkgodara/java-point-of-sale/master/screenshots/java-pos-sales-invoice-data3.png?raw=true "login")

### Sales Invoice End - POS
![Sales Invoice End - POS](https://raw.github.com/inforkgodara/java-point-of-sale/master/screenshots/java-pos-sales-invoice-end.png?raw=true "login")
